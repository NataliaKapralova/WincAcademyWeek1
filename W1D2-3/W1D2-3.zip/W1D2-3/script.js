console.log('Hallo Winc Academy studenten')

//Dit is een grote som

/*

let num1 = 1230941;
let num2 = 1823794;

console.log(num1 * num2); 

// Code werkt in node. Door het zien van uitkomst

let num3 =  637263 ;
let num4 = 54; 

console.log(num3 / num4); */

// Code werkt niet meer omdat code tussen comments staat en dus word genegeerd. 