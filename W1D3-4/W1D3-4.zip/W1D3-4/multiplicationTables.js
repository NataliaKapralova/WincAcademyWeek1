let multiplier = 9; 
for (i = 0; i <= 10; i++){ 
    let result = multiplier * i; 
    console.log( multiplier + '*' + i + '=' + result ); 

}