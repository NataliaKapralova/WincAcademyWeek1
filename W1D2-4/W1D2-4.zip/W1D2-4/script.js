
// alcohol control 

const age = 18;

if (age  => 18 ){ 
 console.log("You good to go");

} else if  (age < 18) { 
    console.log("You are not old enough!");
}


// Ladies night 

const isFemale = true; 

if (isFemale === true ){ 
    console.log('Welkom Ladies')

} else if (isFemale === false ) { 
    console.log('Youre not invited')
}; 

// Drive save 


const driverStatus = 'bob.'; 

if (driverStatus === 'bob.' ) { 
    console.log('Good man') 
 }  
 
 else if ( driverStatus === 'drunk.')
{    console.log('You cant drive') }
