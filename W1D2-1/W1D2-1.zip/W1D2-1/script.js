console.log('Hello winc academy'); 

let myName = 'Natalia' ; // This is my name displayed as a STRING 

console.log(myName) ; // This is my name displayed as a STRING 


// let if = 'natalia' ; Cannot log because the word if is reserved keyword. 

// console.log(name) ; 



const herAge = 30; 
const myAge = 21 ;

console.log(herAge + myAge); 

let firstName = "Natalia"; 
const lastName = "Kapralova" ;

console.log(firstName  + lastName); 

//  Addition 
let a = 2; 
let b = 2; 

console.log(a+b); 



//  Substraction 
let c = 8; 
let d = 4; 

console.log(c-d); 


// Multiplication 
let e = 10; 
let f = 10; 

console.log(e * f ); 

// Division 
let g = 62; 
let h = 4 ; 

console.log(g/h); 

// Modulus 
let i = 20; 
let j = 100  ; 

console.log( i % j); 


let age = 21 ; // This is a number 

console.log(typeof age) // This is a number 

let age2 = 'twentyOne'; // This is a String 

console.log (typeof age2 ) // This is a String 

