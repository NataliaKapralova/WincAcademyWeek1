const calculateDogAge = function(age){

    let dogAge = age*7;
    console.log("Your doggie is " + dogAge + " years old in dog years!");
}

calculateDogAge(1);
calculateDogAge(5);
calculateDogAge(3);